1)we have to import the project source into STS or eclipse IDE.

2)once imported,we have do deployment like Build and Server start.

3)once server is up ,then we have run below URL in the browser

http://localhost:8080/getdatareconciliation

4) In browser we can see the output like Json format as expected result.